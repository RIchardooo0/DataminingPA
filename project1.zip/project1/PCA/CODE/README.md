# README

python package used :
Python 3.7.1
numpy
pandas 
mataplotlib 
sklearn

Execution in command line:
python3 PCA.py


