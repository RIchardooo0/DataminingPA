***************
* Data Format *
***************

Each line represents one data sample.
The last column of each line is class label, either 0 or 1.
The rest columns are feature values, each of them can be a real-value (continuous type) or a string (nominal type).
